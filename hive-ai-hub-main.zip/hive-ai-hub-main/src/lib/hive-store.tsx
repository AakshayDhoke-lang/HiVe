import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type Subject = {
  id: string;
  name: string;
  color: string;
};

export type Pdf = {
  id: string;
  name: string;
  size: number;
  subjectId: string | null;
  uploadedAt: number;
  preview?: string;
  processing?: boolean;
};


export type Message = {
  id: string;
  role: "user" | "assistant";
  content: string;
  sources?: string[];
  createdAt: number;
};

export type Conversation = {
  id: string;
  title: string;
  subjectId: string | null;
  messages: Message[];
  createdAt: number;
};

export type AiProvider = "openai" | "lmstudio" | "ollama" | "custom";

export type AiConfig = {
  provider: AiProvider;
  baseUrl: string;
  apiKey: string;
  model: string;
  clientSide: boolean;
};


export type User = {
  name: string;
  email: string;
  avatar?: string;
};

type State = {
  user: User | null;
  subjects: Subject[];
  pdfs: Pdf[];
  conversations: Conversation[];
  activeSubjectId: string | null;
  activeConversationId: string | null;
  aiConfig: AiConfig;
  sidebarCollapsed: boolean;
  /** slug -> conversationId */
  shares: Record<string, string>;
};

type Ctx = State & {
  setUser: (u: User | null) => void;
  addSubject: (s: Omit<Subject, "id">) => Subject;
  updateSubject: (id: string, patch: Partial<Subject>) => void;
  deleteSubject: (id: string) => void;
  setActiveSubject: (id: string | null) => void;
  addPdfs: (files: File[], opts?: { processing?: boolean }) => Pdf[];
  updatePdf: (id: string, patch: Partial<Pdf>) => void;
  deletePdf: (id: string) => void;
  newConversation: (subjectId: string | null) => Conversation;
  setActiveConversation: (id: string | null) => void;
  sendMessage: (text: string) => Promise<void>;
  clearActiveConversation: () => void;
  deleteConversation: (id: string) => void;
  getShareSlug: (conversationId: string) => string | undefined;
  createShare: (conversationId: string) => string;
  revokeShare: (conversationId: string) => void;
  setAiConfig: (c: AiConfig) => void;
  toggleSidebar: () => void;
};

const HiveContext = createContext<Ctx | null>(null);

const STORAGE_KEY = "hive:state:v1";

const DEFAULT_SUBJECTS: Subject[] = [
  { id: "s_general", name: "General", color: "#7c3aed" },
  { id: "s_contracts", name: "Contracts", color: "#3b82f6" },
  { id: "s_research", name: "Research", color: "#10b981" },
];

const DEFAULT_AI: AiConfig = {
  provider: "openai",
  baseUrl: "https://api.openai.com/v1",
  apiKey: "",
  model: "gpt-4o-mini",
  clientSide: false,
};


function loadInitial(): State {
  if (typeof window === "undefined") {
    return {
      user: null,
      subjects: DEFAULT_SUBJECTS,
      pdfs: [],
      conversations: [],
      activeSubjectId: null,
      activeConversationId: null,
      aiConfig: DEFAULT_AI,
      sidebarCollapsed: false,
      shares: {},
    };
  }
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as State;
      return { ...parsed, shares: parsed.shares ?? {}, aiConfig: { ...DEFAULT_AI, ...(parsed.aiConfig ?? {}) } };
    }
  } catch {}

  return {
    user: { name: "Demo User", email: "demo@hive.app" },
    subjects: DEFAULT_SUBJECTS,
    pdfs: [],
    conversations: [],
    activeSubjectId: null,
    activeConversationId: null,
    aiConfig: DEFAULT_AI,
    sidebarCollapsed: false,
    shares: {},
  };
}

const uid = () => Math.random().toString(36).slice(2, 10);

const blobUrls = new Map<string, string>();

export function getPdfBlobUrl(id: string): string | undefined {
  return blobUrls.get(id);
}

export function HiveProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<State>(loadInitial);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {}
  }, [state]);


  const value: Ctx = useMemo(() => {
    const update = (patch: Partial<State> | ((s: State) => Partial<State>)) =>
      setState((s) => ({ ...s, ...(typeof patch === "function" ? patch(s) : patch) }));

    const ensureConversation = (s: State, subjectId: string | null): Conversation => {
      const existing = s.conversations.find((c) => c.id === s.activeConversationId);
      if (existing) return existing;
      const conv: Conversation = {
        id: "c_" + uid(),
        title: "New chat",
        subjectId,
        messages: [],
        createdAt: Date.now(),
      };
      return conv;
    };

    return {
      ...state,
      setUser: (user) => update({ user }),
      addSubject: (s) => {
        const sub: Subject = { id: "s_" + uid(), ...s };
        update((cur) => ({ subjects: [...cur.subjects, sub] }));
        return sub;
      },
      updateSubject: (id, patch) =>
        update((cur) => ({
          subjects: cur.subjects.map((s) => (s.id === id ? { ...s, ...patch } : s)),
        })),
      deleteSubject: (id) =>
        update((cur) => ({
          subjects: cur.subjects.filter((s) => s.id !== id),
          pdfs: cur.pdfs.map((p) => (p.subjectId === id ? { ...p, subjectId: null } : p)),
          activeSubjectId: cur.activeSubjectId === id ? null : cur.activeSubjectId,
        })),
      setActiveSubject: (id) =>
        update({ activeSubjectId: id, activeConversationId: null }),
      addPdfs: (files, opts) => {
        const newPdfs: Pdf[] = files.map((f) => {
          const id = "p_" + uid();
          try {
            blobUrls.set(id, URL.createObjectURL(f));
          } catch {}
          return {
            id,
            name: f.name,
            size: f.size,
            subjectId: state.activeSubjectId,
            uploadedAt: Date.now(),
            preview: undefined,
            processing: opts?.processing ?? false,
          };
        });
        update((cur) => ({ pdfs: [...newPdfs, ...cur.pdfs] }));
        return newPdfs;
      },
      updatePdf: (id, patch) =>
        update((cur) => ({
          pdfs: cur.pdfs.map((p) => (p.id === id ? { ...p, ...patch } : p)),
        })),
      deletePdf: (id) => {
        const url = blobUrls.get(id);
        if (url) {
          try { URL.revokeObjectURL(url); } catch {}
          blobUrls.delete(id);
        }
        update((cur) => ({ pdfs: cur.pdfs.filter((p) => p.id !== id) }));
      },

      newConversation: (subjectId) => {
        const conv: Conversation = {
          id: "c_" + uid(),
          title: "New chat",
          subjectId,
          messages: [],
          createdAt: Date.now(),
        };
        update((cur) => ({
          conversations: [conv, ...cur.conversations],
          activeConversationId: conv.id,
        }));
        return conv;
      },
      setActiveConversation: (id) => update({ activeConversationId: id }),
      sendMessage: async (text) => {
        const userMsg: Message = {
          id: "m_" + uid(),
          role: "user",
          content: text,
          createdAt: Date.now(),
        };
        let convId = state.activeConversationId;
        setState((cur) => {
          let conversations = cur.conversations;
          let activeConversationId = convId;
          if (!activeConversationId) {
            const conv = ensureConversation(cur, cur.activeSubjectId);
            conv.title = text.slice(0, 40);
            conv.messages = [userMsg];
            conversations = [conv, ...conversations];
            activeConversationId = conv.id;
          } else {
            conversations = conversations.map((c) =>
              c.id === activeConversationId
                ? {
                    ...c,
                    title: c.messages.length === 0 ? text.slice(0, 40) : c.title,
                    messages: [...c.messages, userMsg],
                  }
                : c,
            );
          }
          convId = activeConversationId;
          return { ...cur, conversations, activeConversationId };
        });

        // Generate assistant reply — either via direct client-side fetch to a
        // local/remote OpenAI-compatible endpoint, or via a placeholder (the
        // backend /api/chat integration plugs in here).
        const cfg = state.aiConfig;
        const sources = state.pdfs
          .filter((p) => !state.activeSubjectId || p.subjectId === state.activeSubjectId)
          .slice(0, 2)
          .map((p) => p.name);

        let content =
          "This is a placeholder response from HiVe. Connect your backend `/api/chat` endpoint to stream real answers grounded in your PDFs.";

        if (cfg.clientSide && cfg.baseUrl) {
          try {
            const res = await fetch(`${cfg.baseUrl.replace(/\/$/, "")}/chat/completions`, {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                ...(cfg.apiKey ? { Authorization: `Bearer ${cfg.apiKey}` } : {}),
              },
              body: JSON.stringify({
                model: cfg.model || "local-model",
                messages: [{ role: "user", content: text }],
              }),
            });
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const data = (await res.json()) as {
              choices?: { message?: { content?: string } }[];
            };
            content =
              data.choices?.[0]?.message?.content ??
              "(No content returned by the local model.)";
          } catch (err) {
            content = `⚠️ Could not connect to local AI at \`${cfg.baseUrl}\`. Please check that your server is running and accepts requests from this origin.`;
          }
        } else {
          await new Promise((r) => setTimeout(r, 900));
        }

        const assistantMsg: Message = {
          id: "m_" + uid(),
          role: "assistant",
          content,
          sources: sources.length && !cfg.clientSide ? sources : undefined,
          createdAt: Date.now(),
        };
        setState((cur) => ({
          ...cur,
          conversations: cur.conversations.map((c) =>
            c.id === convId ? { ...c, messages: [...c.messages, assistantMsg] } : c,
          ),
        }));
      },

      clearActiveConversation: () =>
        update((cur) => ({
          conversations: cur.conversations.map((c) =>
            c.id === cur.activeConversationId ? { ...c, messages: [] } : c,
          ),
        })),
      deleteConversation: (id) =>
        update((cur) => {
          const nextShares = { ...cur.shares };
          for (const [slug, cid] of Object.entries(nextShares)) {
            if (cid === id) delete nextShares[slug];
          }
          return {
            conversations: cur.conversations.filter((c) => c.id !== id),
            activeConversationId:
              cur.activeConversationId === id ? null : cur.activeConversationId,
            shares: nextShares,
          };
        }),
      getShareSlug: (conversationId) => {
        const entry = Object.entries(state.shares).find(([, id]) => id === conversationId);
        return entry?.[0];
      },
      createShare: (conversationId) => {
        const existing = Object.entries(state.shares).find(([, id]) => id === conversationId);
        if (existing) return existing[0];
        const slug = uid() + uid();
        update((cur) => ({ shares: { ...cur.shares, [slug]: conversationId } }));
        return slug;
      },
      revokeShare: (conversationId) =>
        update((cur) => {
          const nextShares = { ...cur.shares };
          for (const [slug, cid] of Object.entries(nextShares)) {
            if (cid === conversationId) delete nextShares[slug];
          }
          return { shares: nextShares };
        }),
      setAiConfig: (aiConfig) => update({ aiConfig }),
      toggleSidebar: () => update((cur) => ({ sidebarCollapsed: !cur.sidebarCollapsed })),
    };
  }, [state]);

  return <HiveContext.Provider value={value}>{children}</HiveContext.Provider>;
}

export function useHive() {
  const ctx = useContext(HiveContext);
  if (!ctx) throw new Error("useHive must be used inside HiveProvider");
  return ctx;
}

export function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
